# Toiture & Tradition - Site Web Couvreur

Site web professionnel pour une entreprise de toiture avec secteur d'activité multi-services.

## 📁 Structure du projet

```
toiture-tradition/
├── index.html          # Page principale
├── assets/
│   └── roofing-bg.jpg  # Image de fond (hero section)
└── README.md
```

## 🚀 Installation

1. **Clonez le repository**
```bash
git clone https://github.com/votre-username/toiture-tradition.git
cd toiture-tradition
```

2. **Ouvrez le fichier**
- Double-cliquez sur `index.html` ou
- Utilisez un serveur local (recommandé):
```bash
# Avec Python 3
python -m http.server 8000

# Avec Node.js
npx http-server
```

3. **Accédez à votre navigateur**
```
http://localhost:8000
```

## 📋 Fonctionnalités

✅ Design responsive (mobile, tablette, desktop)
✅ Navigation avec menu hamburger
✅ Changement de langue (FR/NL)
✅ Section héros avec image de fond
✅ Carousel d'avantages
✅ Formulaire de contact
✅ Animations au scroll
✅ Performance optimisée

## 🎨 Personnalisation

### Modifier les couleurs
Éditer les variables CSS au début du `<style>`:
```css
:root {
    --primary: #1a2332;      /* Couleur principale */
    --secondary: #c4935c;    /* Couleur secondaire (or) */
    --accent: #e74c3c;       /* Couleur d'accent */
}
```

### Remplacer l'image de fond
1. Placez votre image dans le dossier `assets/`
2. Modifiez le CSS (cherchez `.hero-section`):
```css
background: linear-gradient(...), url('assets/votre-image.jpg') center/cover no-repeat;
```

### Ajouter du contenu
- Modifiez les textes directement dans le HTML
- Pour multilingue, mettez à jour l'objet `translations` en fin de fichier

## 📧 Formulaire de contact

Le formulaire utilise `mailto:` pour envoyer les messages par email. Modifiez l'adresse email:
```javascript
const mailtoLink = `mailto:VOTRE-EMAIL@example.com?subject=...`
```

## 📱 Optimisations

- Images optimisées pour web (JPG)
- CSS minifié
- Fonts Google chargées depuis CDN
- Smooth scroll sur tous les navigateurs
- Meta tags pour SEO

## 🔗 Dépendances externes

- **Font Awesome 6.4.0** - Icons
- **Google Fonts** - Playfair Display & Inter

## 💾 Déploiement

### Sur GitHub Pages
1. Poussez votre code sur GitHub
2. Allez dans Settings → Pages
3. Sélectionnez la branche `main` comme source
4. Votre site sera accessible à `https://username.github.io/toiture-tradition`

### Sur Netlify
```bash
npm install -g netlify-cli
netlify deploy
```

### Sur Render, Vercel, etc.
Connectez votre repository GitHub et déployez automatiquement à chaque push.

## 📝 Licence

Ce projet est libre d'utilisation pour usage commercial.

## 🤝 Support

Pour toute question ou modification, contactez le développeur.

---

**Dernière mise à jour:** Mai 2026
