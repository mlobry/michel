# 🚀 Guide d'installation pour GitHub

## Étape 1: Télécharger les fichiers

Vous avez reçu un dossier `toiture-tradition/` contenant:

```
toiture-tradition/
│
├── 📄 index.html          ← Page principale (le site)
├── 📁 assets/             ← Dossier des images
│   └── roofing-bg.jpg     ← Image de fond du héros
├── 📝 README.md           ← Documentation
└── 📋 .gitignore          ← Fichier Git (optionnel)
```

## Étape 2: Tester localement AVANT GitHub

### Option A: Ouvrir directement le fichier
1. Double-cliquez sur `index.html`
2. Votre navigateur s'ouvre avec le site
3. ⚠️ **Note**: L'image de fond peut ne pas charger en local si vous ouvrez le fichier directement

### Option B: Utiliser un serveur local (RECOMMANDÉ ✅)

**Avec Python (le plus simple):**
```bash
# Ouvrez Terminal/PowerShell dans le dossier toiture-tradition/
# Tapez:
python -m http.server 8000

# Puis allez à: http://localhost:8000
```

**Avec Node.js:**
```bash
npx http-server
```

**Avec VS Code:**
1. Installez l'extension "Live Server"
2. Clic droit sur `index.html` → "Open with Live Server"

## Étape 3: Créer un repository GitHub

### Sur GitHub.com:

1. **Créez un nouveau repository**
   - Clic sur le `+` → "New repository"
   - Nom: `toiture-tradition`
   - Description: "Site web professionnel couvreur"
   - Privé ou Public (vous choisissez)
   - ✅ Cochez "Add a README"
   - Clic "Create repository"

2. **Clonez sur votre ordinateur**
   ```bash
   git clone https://github.com/VOTRE-USERNAME/toiture-tradition.git
   cd toiture-tradition
   ```

3. **Remplacez les fichiers**
   - Supprimer les fichiers auto-générés
   - Copier/coller le contenu de votre dossier `toiture-tradition/` dans le repo cloné

## Étape 4: Pusher sur GitHub

```bash
# Dans le dossier toiture-tradition/
git add .
git commit -m "Initial commit: site couvreur avec image de fond"
git push origin main
```

## Étape 5: Activer GitHub Pages

1. Allez sur votre repo GitHub
2. Settings → Pages
3. Sélectionnez **Source**: `main` branch
4. Clic "Save"
5. ✅ Votre site sera accessible à:
   ```
   https://VOTRE-USERNAME.github.io/toiture-tradition
   ```

## ⚠️ Dépannage

### L'image de fond n'apparaît pas?

**Vérifiez que la structure est exacte:**
```
toiture-tradition/
├── index.html
└── assets/
    └── roofing-bg.jpg    ← Important!
```

L'image DOIT être dans un sous-dossier `assets/` nommé exactement `roofing-bg.jpg`.

**Solution:**
1. Ouvrez `index.html` avec un éditeur (VS Code, Notepad++)
2. Cherchez `assets/roofing-bg.jpg`
3. Assurez-vous que le chemin correspond à votre structure

### Le site est vide?

- ✅ Vérifiez que `index.html` est présent
- ✅ Utilisez un serveur local, pas l'ouverture directe du fichier
- ✅ Rechargez la page (Ctrl+F5 ou Cmd+Shift+R)

### Les fonts/icônes manquent?

- C'est normal au démarrage, elles chargent depuis CDN
- Attendez quelques secondes
- Vérifiez votre connexion internet

## 📱 Tester sur téléphone

Avec un serveur local:
```bash
# Trouvez votre adresse IP locale
ipconfig (Windows) ou ifconfig (Mac/Linux)

# Allez sur: http://VOTRE-IP:8000 depuis votre téléphone sur le même WiFi
```

## 🔧 Modifications futures

Pour modifier le contenu:
1. Éditez `index.html` avec un éditeur de texte
2. Sauvegardez
3. Rechargez dans le navigateur
4. Pushez sur GitHub:
   ```bash
   git add .
   git commit -m "Mise à jour: [description]"
   git push
   ```

## 🎨 Ajouter votre logo/images

1. Placez vos images dans le dossier `assets/`
2. Référencez-les dans `index.html`:
   ```html
   <img src="assets/ma-image.jpg" alt="Description">
   ```

## 📞 Besoin d'aide?

- 📖 Lisez le `README.md` pour plus de détails
- 🔍 Cherchez l'erreur dans la console du navigateur (F12)
- 💬 GitHub Issues pour des problèmes

---

**Bonne chance! 🚀**
